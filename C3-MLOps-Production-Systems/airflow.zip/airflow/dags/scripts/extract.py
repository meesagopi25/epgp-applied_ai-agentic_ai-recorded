import pandas as pd
import requests

def get_api_data(output_path):
    # Using a public dummy sales API
    url = "https://fakestoreapi.com/products"
    response = requests.get(url)
    df = pd.DataFrame(response.json())
    df.to_csv(output_path, index=False)