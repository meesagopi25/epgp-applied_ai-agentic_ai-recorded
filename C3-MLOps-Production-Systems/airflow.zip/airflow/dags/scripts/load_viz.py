import pandas as pd
import plotly.express as px

def create_chart(input_path, html_path):
    df = pd.read_csv(input_path)
    fig = px.line(df, x='category', y='price', title='Total Sales Value by Category')
    fig.write_html(html_path)