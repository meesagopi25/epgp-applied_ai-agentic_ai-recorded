import pandas as pd

def clean_and_aggregate(input_path, output_path):
    df = pd.read_csv(input_path)
    # Simple cleaning: Keep relevant columns and aggregate price by category
    clean_df = df[['category', 'price', 'rating']]
    # Converting rating (dict) to a simple number
    clean_df['rating_score'] = df['rating'].apply(lambda x: eval(x)['rate'] if isinstance(x, str) else x['rate'])
    
    summary = clean_df.groupby('category')['price'].sum().reset_index()
    summary.to_csv(output_path, index=False)