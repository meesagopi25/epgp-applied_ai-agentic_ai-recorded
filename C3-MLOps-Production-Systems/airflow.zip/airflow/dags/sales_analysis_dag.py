from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import os

# Import your custom functions
from scripts.extract import get_api_data
from scripts.transform import clean_and_aggregate
from scripts.load_viz import create_chart

# Paths (Inside Docker, /opt/airflow is the base)
# test 
DATA_DIR = "/opt/airflow/dags/scripts/data"
os.makedirs(DATA_DIR, exist_ok=True)

RAW_DATA = f"{DATA_DIR}/raw_data.csv"
CLEAN_DATA = f"{DATA_DIR}/summary_data.csv"
REPORT_PATH = "/opt/airflow/outputs/sales_report.html"

with DAG(
    dag_id='sales_api_pipeline_v1',
    start_date=datetime(2025, 1, 1),
    schedule='@daily',
    catchup=False
) as dag:

    task_extract = PythonOperator(
        task_id='extract_from_api',
        python_callable=get_api_data,
        op_kwargs={'output_path': RAW_DATA}
    )

    task_transform = PythonOperator(
        task_id='clean_and_aggregate',
        python_callable=clean_and_aggregate,
        op_kwargs={'input_path': RAW_DATA, 'output_path': CLEAN_DATA}
    )

    task_visualize = PythonOperator(
        task_id='generate_html_chart',
        python_callable=create_chart,
        op_kwargs={'input_path': CLEAN_DATA, 'html_path': REPORT_PATH}
    )

    # Define the dependency flow
    task_extract >> task_transform >> task_visualize