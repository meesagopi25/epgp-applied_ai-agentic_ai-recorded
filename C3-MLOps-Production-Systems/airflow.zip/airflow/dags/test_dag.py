from airflow.models.dag import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

with DAG(
    dag_id="docker_test_dag",
    start_date=datetime(2025, 1, 1),
    schedule="@daily",
    catchup=False
) as dag:

    hello_task = BashOperator(
        task_id="say_hello",
        bash_command="echo 'Hello Ganesh from inside Docker!'"
    )